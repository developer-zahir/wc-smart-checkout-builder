/**
 * WooCommerce Product Variation & Checkout Elementor Widget
 * Script: widget.js
 */

(function ($) {
	'use strict';

	/**
	 * Widget Controller Class
	 */
	function WCSCWidget($container) {
		this.$container = $container;
		this.productId = parseInt($container.data('product-id'), 10) || 0;
		this.productType = $container.data('product-type') || 'simple';
		this.defaultPriceHtml = $container.data('default-price') || '';
		this.rawPriceText = $container.data('raw-price') || '';
		this.$mainImg = $container.find('.wcsc-main-product-img');
		this.originImgSrc = this.$mainImg.data('origin-src') || this.$mainImg.attr('src');
		this.$priceContainer = $container.find('.wcsc-product-price');
		this.$stockContainer = $container.find('.wcsc-stock-status');
		this.$qtyInput = $container.find('.wcsc-qty-input');
		this.$loadingOverlay = $container.find('.wcsc-loading-overlay');
		this.currentVariationId = 0;
		this.isEditor = window.wcsc_params && window.wcsc_params.is_elementor_edit;
		this.syncTimeout = null;

		// Parse variation data
		var $varDataScript = $container.find('.wcsc-variations-data');
		this.variations = [];
		if ($varDataScript.length) {
			try {
				this.variations = JSON.parse($varDataScript.html()) || [];
			} catch (e) {
				console.error('WCSC: Failed to parse variations data', e);
			}
		}

		this.init();
	}

	WCSCWidget.prototype = {
		init: function () {
			this.bindEvents();
			this.applyCustomTexts();
			this.styleShippingMethods();
			this.stylePaymentMethods();

			// Match default or initial variation on load
			if (this.productType === 'variable') {
				this.checkInitialSelection();
			} else {
				// Simple product initial button price
				if (this.rawPriceText) {
					this.updateButtonPrice(this.rawPriceText);
				}
			}

			this.syncOrderButtonPrice();
			this.initMobileStickyObserver();
			this.syncOrderButtonAnimationColor();
		},

		bindEvents: function () {
			var self = this;

			// Swatch Click
			this.$container.on('click', '.wcsc-swatch', function (e) {
				e.preventDefault();
				var $swatch = $(this);
				if ($swatch.hasClass('is-disabled')) {
					return;
				}

				var $group = $swatch.closest('.wcsc-attribute-group');
				var val = $swatch.data('value');
				var label = $swatch.data('label') || val;

				// Toggle selection
				$group.find('.wcsc-swatch').removeClass('is-selected');
				$swatch.addClass('is-selected');
				$group.find('.wcsc-attribute-input').val(val);

				var template = $group.find('.wcsc-attribute-header').attr('data-label-template');
				if (template) {
					if (/\{+(?:value|selected_variation)\}+/i.test(template)) {
						$group.find('.wcsc-attribute-label').text(template.replace(/\{+(?:value|selected_variation)\}+/gi, label));
					} else {
						$group.find('.wcsc-attribute-label').text(template);
					}
					$group.find('.wcsc-selected-value-label').text('');
				} else {
					$group.find('.wcsc-selected-value-label').text(label);
				}

				self.onAttributeChange();
			});

			// Quantity Plus / Minus
			this.$container.on('click', '.wcsc-qty-plus', function (e) {
				e.preventDefault();
				var current = parseInt(self.$qtyInput.val(), 10) || 1;
				var max = parseInt(self.$qtyInput.attr('max'), 10) || 9999;
				if (current < max) {
					self.$qtyInput.val(current + 1).trigger('change');
				}
			});

			this.$container.on('click', '.wcsc-qty-minus', function (e) {
				e.preventDefault();
				var current = parseInt(self.$qtyInput.val(), 10) || 1;
				var min = parseInt(self.$qtyInput.attr('min'), 10) || 1;
				if (current > min) {
					self.$qtyInput.val(current - 1).trigger('change');
				}
			});

			// Quantity Change
			this.$container.on('change', '.wcsc-qty-input', function () {
				var qty = parseInt($(this).val(), 10) || 1;
				var min = parseInt($(this).attr('min'), 10) || 1;
				if (qty < min) {
					$(this).val(min);
				}
				self.debouncedSync();
			});

			// Listen to WooCommerce checkout updates (guarded: only when our wrapper is present)
			$(document.body).on('updated_checkout', function (event, data) {
				if (!self.$container.find('.wcas-checkout-wrapper').length && !$('.wcas-checkout-wrapper').length) return;
				self.hideLoading();
				self.applyCustomTexts();
				self.styleShippingMethods();
				self.stylePaymentMethods();

				// Synchronously sync Order Now button price
				self.syncOrderButtonPrice();

				// Suppress any inline WooCommerce error notices injected during AJAX (scoped)
				$('.wcsc-product-checkout-widget .woocommerce-NoticeGroup-checkout, .wcsc-product-checkout-widget .woocommerce-NoticeGroup, .wcsc-product-checkout-widget .woocommerce-error, .wcsc-product-checkout-widget .checkout-inline-error-message, .wcas-checkout-wrapper .woocommerce-NoticeGroup-checkout, .wcas-checkout-wrapper .woocommerce-NoticeGroup, .wcas-checkout-wrapper .woocommerce-error, .wcas-checkout-wrapper .checkout-inline-error-message').hide().remove();

				// Ensure Order Review item thumbnail matches current selected variation ONLY for main product (first item)
				if (self.currentVariationId && self.variations.length) {
					for (var i = 0; i < self.variations.length; i++) {
						if (self.variations[i].variation_id === self.currentVariationId) {
							if (self.variations[i].image && self.variations[i].image.src) {
								var $cartImg = self.$container.find('.woocommerce-checkout-review-order-table tbody tr.wcas-order-review-product:first .wcsc-cart-item-image, .woocommerce-checkout-review-order-table tbody tr.cart_item:first .wcsc-cart-item-image');
								if ($cartImg.length) {
									$cartImg.attr('src', self.variations[i].image.src).removeAttr('srcset');
								}
							}
							break;
						}
					}
				}

				// CRITICAL BUG FIX: Ensure secondary duplicate order buttons injected into #payment by native WC AJAX are removed
				self.$container.find('.wcas-block-payment #place_order, .wcas-block-payment .place-order').remove();
			});

			// Catch WooCommerce AJAX updates for shipping/totals recalculation (guarded)
			$(document).ajaxComplete(function (event, xhr, settings) {
				if (!$('.wcas-checkout-wrapper').length) return;
				if (settings && ((settings.data && typeof settings.data === 'string' && settings.data.indexOf('update_order_review') !== -1) || (settings.url && settings.url.indexOf('update_order_review') !== -1))) {
					setTimeout(function () {
						self.syncOrderButtonPrice();
					}, 50);
				}
			});

			$(document.body).on('checkout_error', function (event, errorMessage) {
				if (!self.$container.find('.wcas-checkout-wrapper').length && !$('.wcas-checkout-wrapper').length) return;
				self.hideLoading();
				self.styleShippingMethods();

				// Prevent browser from scrolling up abruptly
				$('html, body').stop();

				// Suppress inline notice group completely
				$('.woocommerce-NoticeGroup-checkout, .wcas-checkout-wrapper .woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-NoticeGroup').hide().remove();

				// Extract and parse error messages
				var messages = [];
				if (errorMessage) {
					var $temp = $('<div>').html(errorMessage);
					$temp.find('li').each(function () {
						var text = $.trim($(this).text());
						if (text && messages.indexOf(text) === -1) {
							messages.push(text);
						}
					});
					if (!messages.length) {
						var rawText = $.trim($temp.text());
						if (rawText && messages.indexOf(rawText) === -1) {
							messages.push(rawText);
						}
					}
				}

				if (!messages.length) {
					self.$container.find('.form-row.woocommerce-invalid, .form-row.woocommerce-invalid-required-field').each(function () {
						var label = $(this).find('label').text().replace(/[\*\:]/g, '').trim();
						var msg = label ? label + ' পূরণ করা বাধ্যতামূলক' : 'প্রয়োজনীয় তথ্য সঠিকভাবে প্রদান করুন';
						if (messages.indexOf(msg) === -1) {
							messages.push(msg);
						}
					});
				}

				if (!messages.length) {
					messages.push('অর্ডার সম্পন্ন করতে প্রয়োজনীয় তথ্য সঠিকভাবে প্রদান করুন।');
				}

				self.showValidationModal(messages);
			});

			// Listen for WooCommerce variation events (guarded: only when our wrapper is present)
			$(document.body).on('found_variation', function (event, variation) {
				if (!$('.wcas-checkout-wrapper').length) return;
				if (variation) {
					self.debouncedSync();
				}
			});

			$(document.body).on('reset_data', function () {
				if (!$('.wcas-checkout-wrapper').length) return;
				self.debouncedSync();
			});

			// Order Bump Card & Button Click / Toggle
			this.$container.on('click', '.wcsc-order-bump-card', function (e) {
				if ($(e.target).is('input[type="checkbox"]') || $(e.target).is('label') || $(e.target).closest('.wcsc-order-bump-btn').length) {
					return;
				}
				e.preventDefault();
				var $card = $(this);
				var $chk = $card.find('.wcsc-order-bump-checkbox');
				var nextState = !$chk.prop('checked');
				$chk.prop('checked', nextState).trigger('change');
			});

			this.$container.on('change', '.wcsc-order-bump-checkbox', function (e) {
				e.stopPropagation();
				var $chk = $(this);
				var productId = $chk.data('product-id');
				var isAdding = $chk.is(':checked');
				var $card = $chk.closest('.wcsc-order-bump-card');
				var $btn = $card.find('.wcsc-order-bump-btn');
				var actionText = $card.data('action-text') || 'অর্ডার যুক্ত করুন';

				$card.toggleClass('is-selected', isAdding);
				$btn.toggleClass('is-active', isAdding);
				$btn.find('.wcsc-order-bump-btn-icon').text(isAdding ? '✓' : '+');
				$btn.find('.wcsc-order-bump-btn-text').text(isAdding ? 'যুক্ত হয়েছে' : actionText);

				self.toggleOrderBump(productId, isAdding ? 'add' : 'remove');
			});

			this.$container.on('click', '.wcsc-order-bump-btn', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var $card = $(this).closest('.wcsc-order-bump-card');
				var $chk = $card.find('.wcsc-order-bump-checkbox');
				var nextState = !$chk.prop('checked');
				$chk.prop('checked', nextState).trigger('change');
			});


			// Make shipping cards clickable
			this.$container.on('click', '.wcsc-shipping-card', function (e) {
				if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'LABEL') {
					var $radio = $(this).find('input[type="radio"]');
					if ($radio.length && !$radio.is(':checked')) {
						$radio.prop('checked', true).trigger('change');
					}
				}
			});
			this.$container.on('change', 'input.shipping_method, #shipping_method input[type="radio"]', function () {
				self.styleShippingMethods();
				setTimeout(function () {
					self.syncOrderButtonPrice();
				}, 60);
			});

			this.$container.on('click', '.wcas-block-payment ul.payment_methods li.wc_payment_method', function (e) {
				if ($(e.target).is('input[type="radio"]') || $(e.target).is('a') || $(e.target).closest('.payment_box').length) {
					return;
				}
				var $radio = $(this).find('input[type="radio"]');
				if ($radio.length && !$radio.is(':checked')) {
					$radio.prop('checked', true).trigger('change');
				}
			});

			this.$container.on('change', 'input[name="payment_method"]', function () {
				self.stylePaymentMethods();
			});

			// Mobile sticky floating order button click -> scroll smoothly to checkout and immediately hide
			this.$container.on('click', '.wcsc-mobile-sticky-btn, .wcsc-floating-btn', function (e) {
				e.preventDefault();
				var stickyBar = self.$container.find('.wcsc-mobile-sticky-bar')[0] || document.getElementById('wcsc-mobile-sticky-bar');
				if (stickyBar) {
					$(stickyBar).addClass('is-hidden');
				}
				var $target = self.$container.find('.wcas-checkout-wrapper');
				if (!$target.length) {
					$target = $('.wcas-checkout-wrapper');
				}
				if ($target.length) {
					$('html, body').animate({
						scrollTop: $target.offset().top - 20
					}, 450);
				}
			});

			// Close modal on close button click (top-left X or bottom button)
			$(document).on('click', '.wcas-modal-top-close-btn, .wcsc-modal-top-close-btn, .wcsc-phone-modal-close-btn, .wcsc-validation-modal-close-btn', function (e) {
				e.preventDefault();
				var $modal = $('#wcsc-validation-modal, #wcsc-phone-modal');
				$modal.fadeOut(200);
				var $firstInvalid = $modal.data('first-invalid') || self.$container.find('.wcsc-invalid, .wcas-input-error').first();
				if ($firstInvalid && $firstInvalid.length) {
					$('html, body').animate({
						scrollTop: $firstInvalid.offset().top - 100
					}, 300);
					$firstInvalid.focus();
				}
			});

			// Close modal on backdrop click
			$(document).on('click', '#wcsc-validation-modal, #wcsc-phone-modal', function (e) {
				if ($(e.target).is('#wcsc-validation-modal, #wcsc-phone-modal')) {
					var $modal = $(this);
					$modal.fadeOut(200);
					var $firstInvalid = $modal.data('first-invalid') || self.$container.find('.wcsc-invalid').first();
					if ($firstInvalid && $firstInvalid.length) {
						$('html, body').animate({
							scrollTop: $firstInvalid.offset().top - 100
						}, 300);
						$firstInvalid.focus();
					}
				}
			});

			// Intercept checkout submit for client-side required field validation & phone validation
			var validateCheckoutForm = function (e) {
				var $form = self.$container.find('form.checkout');
				if ($form.length) {
					// Block submission completely if plugin license is unauthorized
					if (self.$container.find('.wcsc-license-unauthorized-notice').length || self.$container.find('#place_order.wcsc-license-unauthorized').length) {
						if (e) {
							e.preventDefault();
							e.stopImmediatePropagation();
						}
						var $notice = self.$container.find('.wcsc-license-unauthorized-notice');
						if ($notice.length) {
							$('html, body').animate({
								scrollTop: $notice.offset().top - 150
							}, 300);
						}
						return false;
					}

					var hasInvalid = false;
					var $firstInvalid = null;
					var missingFields = [];

					// Clear previous error states
					$form.find('.wcsc-invalid, .wcas-input-error').removeClass('wcsc-invalid wcas-input-error');
					$form.find('.form-row.woocommerce-invalid').removeClass('woocommerce-invalid');

					// 1. Validate all visible required fields
					$form.find('input[required], textarea[required], select[required], .validate-required input.input-text, .validate-required textarea, .validate-required select, .validate-required input').each(function () {
						var $field = $(this);
						if (!$field.is(':visible') || $field.is(':disabled')) {
							return;
						}
						var val = $.trim($field.val() || '');
						if (!val) {
							hasInvalid = true;
							$field.addClass('wcsc-invalid wcas-input-error');
							$field.closest('.form-row').addClass('woocommerce-invalid');
							if (!$firstInvalid) {
								$firstInvalid = $field;
							}
							var nameAttr = ($field.attr('name') || '').toLowerCase();
							var msg = '';
							if (nameAttr.indexOf('first_name') !== -1 || nameAttr.indexOf('last_name') !== -1 || nameAttr.indexOf('name') !== -1) {
								msg = 'আপনার নাম প্রদান করুন';
							} else if (nameAttr.indexOf('phone') !== -1) {
								msg = 'আপনার মোবাইল নম্বরটি দিন';
							} else if (nameAttr.indexOf('address_1') !== -1 || nameAttr.indexOf('address') !== -1) {
								msg = 'আপনার সম্পূর্ণ ঠিকানা প্রদান করুন';
							} else if (nameAttr.indexOf('city') !== -1) {
								msg = 'শহর / জেলা প্রদান করুন';
							} else {
								var label = $field.closest('.form-row').find('label').text().replace(/[\*\:]/g, '').trim();
								msg = label ? label + ' পূরণ করা বাধ্যতামূলক' : 'প্রয়োজনীয় তথ্য প্রদান করুন';
							}
							if (missingFields.indexOf(msg) === -1) {
								missingFields.push(msg);
							}
						}
					});

					// 2. Validate phone format ONLY if phone field is non-empty and validation is enabled
					var $hasValidation = self.$container.find('input[name="wcsc_bd_phone_validation"]');
					var $phone = self.$container.find('input[name="billing_phone"]');
					if ($phone.length && $phone.is(':visible')) {
						var rawPhone = $.trim($phone.val() || '').replace(/[\s\-\(\)]/g, '');
						if (rawPhone) {
							if ($hasValidation.length && $hasValidation.val() === '1') {
								var bdPhoneRegex = /^(?:\+?880|880|0)?1[3-9]\d{8}$/;
								if (!bdPhoneRegex.test(rawPhone)) {
									hasInvalid = true;
									$phone.addClass('wcsc-invalid wcas-input-error');
									$phone.closest('.form-row').addClass('woocommerce-invalid');
									var phoneErr = '১১ সংখ্যার একটি সঠিক মোবাইল নম্বর প্রদান করুন';
									if (missingFields.indexOf(phoneErr) === -1) {
										missingFields.push(phoneErr);
									}
									if (!$firstInvalid) {
										$firstInvalid = $phone;
									}
								}
							}
						}
					}

					if (hasInvalid && missingFields.length > 0) {
						if (e) {
							e.preventDefault();
							e.stopImmediatePropagation();
						}
						self.showValidationModal(missingFields, $firstInvalid);
						return false;
					}
				}
				return true;
			};

			this.$container.on('click', '#place_order, .wcsc-order-now-btn', function (e) {
				if ($(this).hasClass('wcsc-license-unauthorized') || self.$container.find('.wcsc-license-unauthorized-notice').length) {
					e.preventDefault();
					e.stopImmediatePropagation();
					var $notice = self.$container.find('.wcsc-license-unauthorized-notice');
					if ($notice.length) {
						$('html, body').animate({
							scrollTop: $notice.offset().top - 150
						}, 300);
					}
					return false;
				}
				if (!validateCheckoutForm(e)) {
					return false;
				}
			});

			this.$container.on('submit', 'form.checkout', function (e) {
				if (!validateCheckoutForm(e)) {
					return false;
				}
			});

			// Clear invalid state on user input/change
			this.$container.on('input change', 'input, textarea, select', function () {
				var $input = $(this);
				if ($.trim($input.val() || '')) {
					$input.removeClass('wcsc-invalid wcas-input-error');
					$input.closest('.form-row').removeClass('woocommerce-invalid');
				}
			});
		},

		showLoading: function () {
			// Removed visual loading overlay as requested
		},

		hideLoading: function () {
			// Removed visual loading overlay as requested
		},

		applyCustomTexts: function () {
			var txtOrder = this.$container.data('txt-order');
			var txtBilling = this.$container.data('txt-billing');
			var txtProduct = this.$container.data('txt-product');
			var txtSubtotal = this.$container.data('txt-subtotal');
			var txtShipping = this.$container.data('txt-shipping');
			var txtPayment = this.$container.data('txt-payment');
			var txtTotal = this.$container.data('txt-total');

			if (txtOrder) {
				this.$container.find('#order_review_heading').text(txtOrder);
			}
			if (txtBilling) {
				this.$container.find('.wcas-block-checkout-form .wcsc-section-title, .woocommerce-billing-fields > h3, #customer_details .col-1 .wcsc-section-title').text(txtBilling);
			}
			if (txtPayment) {
				this.$container.find('.wcas-block-payment .wcsc-section-title').text(txtPayment);
			}
			if (txtProduct) {
				this.$container.find('table.shop_table th.product-name').text(txtProduct);
			}
			if (txtSubtotal) {
				this.$container.find('table.shop_table th.product-total').text(txtSubtotal);
				this.$container.find('table.shop_table tr.cart-subtotal th').text(txtSubtotal);
			}
			if (txtShipping) {
				this.$container.find('table.shop_table tr.woocommerce-shipping-totals th').text(txtShipping);
				this.$container.find('.wcsc-shipping-heading').text(txtShipping);
			}
			if (txtTotal) {
				this.$container.find('table.shop_table tr.order-total th').text(txtTotal);
			}
		},

		styleShippingMethods: function () {
			var $wrapper = this.$container.find('.wcas-checkout-wrapper');
			if (!$wrapper.length) return;

			// Ship methods are rendered natively inside the plugin-owned
			// .wcas-block-shipping container by the PHP layer. JS only adds
			// the interactive card classes (.wcsc-shipping-card / .is-active)
			// so the CSS styling and click-to-select behaviour work.
			var $methods = $wrapper.find('.wcas-block-shipping #shipping_method li');
			if ($methods.length) {
				if (!$methods.find('input[type="radio"]:checked').length) {
					$methods.first().find('input[type="radio"]').prop('checked', true).trigger('change');
				}
				$methods.each(function () {
					var $li = $(this);
					$li.addClass('wcsc-shipping-card');
					if ($li.find('input[type="radio"]').is(':checked')) {
						$li.addClass('is-active');
					} else {
						$li.removeClass('is-active');
					}
				});
			}
		},

		stylePaymentMethods: function () {
			var $wrapper = this.$container.find('.wcas-checkout-wrapper');
			if (!$wrapper.length) return;

			var $methods = $wrapper.find('.wcas-block-payment ul.payment_methods li.wc_payment_method');
			if ($methods.length) {
				if (!$methods.find('input[type="radio"]:checked').length) {
					$methods.first().find('input[type="radio"]').prop('checked', true).trigger('change');
				}
				$methods.each(function () {
					var $li = $(this);
					if ($li.find('input[type="radio"]').is(':checked')) {
						$li.addClass('is-active');
					} else {
						$li.removeClass('is-active');
					}
				});
			}
		},

		checkInitialSelection: function () {
			var self = this;
			var $groups = this.$container.find('.wcsc-attribute-group');

			$groups.each(function () {
				var $group = $(this);
				var $selected = $group.find('.wcsc-swatch.is-selected');
				if (!$selected.length) {
					// Select first available option as initial default
					$selected = $group.find('.wcsc-swatch:not(.is-disabled)').first();
					if ($selected.length) {
						$selected.addClass('is-selected');
						$group.find('.wcsc-attribute-input').val($selected.data('value'));
					}
				}
				if ($selected.length) {
					var valLabel = $selected.data('label') || $selected.data('value');
					var template = $group.find('.wcsc-attribute-header').attr('data-label-template');
					if (template) {
						if (/\{+(?:value|selected_variation)\}+/i.test(template)) {
							$group.find('.wcsc-attribute-label').text(template.replace(/\{+(?:value|selected_variation)\}+/gi, valLabel));
						} else {
							$group.find('.wcsc-attribute-label').text(template);
						}
						$group.find('.wcsc-selected-value-label').text('');
					} else {
						$group.find('.wcsc-selected-value-label').text(valLabel);
					}
				}
			});

			this.onAttributeChange(true);
		},

		getSelectedAttributes: function () {
			var attrs = {};
			this.$container.find('.wcsc-attribute-group').each(function () {
				var $group = $(this);
				var attrName = $group.data('attribute-name');
				var val = $group.find('.wcsc-attribute-input').val();
				if (attrName) {
					attrs[attrName] = val;
				}
			});
			return attrs;
		},

		onAttributeChange: function (isInitial) {
			var selectedAttrs = this.getSelectedAttributes();
			var matchedVariation = this.findMatchingVariation(selectedAttrs);

			if (matchedVariation) {
				this.currentVariationId = matchedVariation.variation_id;

				// Update Price display in product summary section
				if (matchedVariation.price_html && this.$priceContainer.length) {
					this.$priceContainer.html(matchedVariation.price_html);
				}

				// Update Main Image
				if (matchedVariation.image && matchedVariation.image.src && this.$mainImg.length) {
					this.$mainImg.attr('src', matchedVariation.image.src);
				} else if (this.originImgSrc && this.$mainImg.length) {
					this.$mainImg.attr('src', this.originImgSrc);
				}

				// Update Order Review item thumbnail (first/main product only)
				var $cartItemImg = this.$container.find('.woocommerce-checkout-review-order-table tbody tr.wcas-order-review-product:first .wcsc-cart-item-image, .woocommerce-checkout-review-order-table tbody tr.cart_item:first .wcsc-cart-item-image');
				if ($cartItemImg.length) {
					if (matchedVariation.image && matchedVariation.image.src) {
						$cartItemImg.attr('src', matchedVariation.image.src).removeAttr('srcset');
					} else if (this.originImgSrc) {
						$cartItemImg.attr('src', this.originImgSrc).removeAttr('srcset');
					}
				}

				// Update Stock
				if (this.$stockContainer.length) {
					if (matchedVariation.is_in_stock) {
						this.$stockContainer.removeClass('out-of-stock').addClass('in-stock');
						if (matchedVariation.availability_html) {
							this.$stockContainer.html(matchedVariation.availability_html);
						} else {
							this.$stockContainer.text(window.wcsc_params ? window.wcsc_params.i18n.in_stock : 'In stock');
						}
					} else {
						this.$stockContainer.removeClass('in-stock').addClass('out-of-stock');
						this.$stockContainer.text(window.wcsc_params ? window.wcsc_params.i18n.out_of_stock : 'Out of stock');
					}
				}

				// Sync with Cart & Checkout
				if (!this.isEditor && !isInitial) {
					this.debouncedSync();
				} else if (this.isEditor) {
					// In Elementor Editor: update visual preview elements
					this.updateEditorPreview(matchedVariation);
				}
			} else {
				// No direct match found
				this.currentVariationId = 0;
			}
		},

		findMatchingVariation: function (selectedAttrs) {
			if (!this.variations || !this.variations.length) {
				return null;
			}

			var normalizeStr = function (str) {
				if (str === null || typeof str === 'undefined') return '';
				try {
					str = decodeURIComponent(String(str));
				} catch (e) {
					str = String(str);
				}
				return str.toLowerCase().trim().replace(/[\s_]+/g, '-');
			};

			for (var i = 0; i < this.variations.length; i++) {
				var variation = this.variations[i];
				var varAttrs = variation.attributes || {};
				var match = true;

				for (var name in selectedAttrs) {
					if (!selectedAttrs.hasOwnProperty(name)) continue;

					var selectedVal = normalizeStr(selectedAttrs[name]);
					var cleanName = normalizeStr(name);
					var cleanNameWithoutPa = cleanName.replace(/^pa-/, '').replace(/^attribute-pa-/, '').replace(/^attribute-/, '');

					// Search all possible keys in varAttrs
					var varVal = null;
					for (var vKey in varAttrs) {
						if (!varAttrs.hasOwnProperty(vKey)) continue;
						var cleanVKey = normalizeStr(vKey);
						var cleanVKeyWithoutPa = cleanVKey.replace(/^pa-/, '').replace(/^attribute-pa-/, '').replace(/^attribute-/, '');

						if (cleanVKey === cleanName || cleanVKeyWithoutPa === cleanNameWithoutPa || cleanVKey === 'attribute-' + cleanName || cleanVKey === 'attribute-pa-' + cleanNameWithoutPa) {
							varVal = varAttrs[vKey];
							break;
						}
					}

					// If attribute was found in variation definition
					if (varVal !== null && typeof varVal !== 'undefined') {
						var normVarVal = normalizeStr(varVal);
						// '' means ANY value is accepted for this variation
						if (normVarVal !== '' && normVarVal !== selectedVal) {
							match = false;
							break;
						}
					}
				}

				if (match) {
					return variation;
				}
			}

			return null;
		},

		decodeHtmlEntities: function (text) {
			if (!text) return '';
			try {
				var tempElem = document.createElement('textarea');
				tempElem.innerHTML = text;
				var decoded = tempElem.value || '';
				if (decoded.indexOf('&') !== -1 && decoded.indexOf(';') !== -1) {
					tempElem.innerHTML = decoded;
					decoded = tempElem.value || decoded;
				}
				return decoded.replace(/\u00a0/g, ' ').trim();
			} catch (e) {
				return String(text).replace(/&amp;/g, '&').replace(/\u00a0/g, ' ').trim();
			}
		},

		syncOrderButtonPrice: function (customPrice) {
			var decodedTotal = '';

			if (customPrice) {
				decodedTotal = this.decodeHtmlEntities(customPrice);
			} else {
				// Extract the updated grand total from WooCommerce order review table (scoped to our container)
				var $totalElement = this.$container.find('.order-total .amount, tr.order-total .woocommerce-Price-amount, .wcsc-ty-totals td, .woocommerce-checkout-review-order-table tr.order-total .woocommerce-Price-amount, .woocommerce-checkout-review-order-table .order-total .woocommerce-Price-amount').last();
				if (!$totalElement.length) {
					$totalElement = this.$container.find('.wcas-checkout-wrapper .order-total .amount, .wcas-checkout-wrapper tr.order-total .woocommerce-Price-amount').last();
				}
				if ($totalElement.length) {
					var rawHtml = $totalElement.html();
					decodedTotal = this.decodeHtmlEntities(rawHtml);
				}
			}

			if (!decodedTotal) {
				return;
			}

			// Clean non-breaking spaces and tags
			decodedTotal = decodedTotal.replace(/\u00a0/g, ' ').replace(/<[^>]*>/g, '').trim();

			// Update all order buttons synchronously (scoped to our container only)
			var $buttons = this.$container.find('#place_order, .wcsc-order-now-btn, .wcas-block-order-button button, .wcsc-mobile-sticky-btn, .wcsc-floating-btn');
			$buttons.each(function () {
				var $button = $(this);
				var templateText = $button.attr('data-template-text') || $button.data('template-text');
				if (!templateText) {
					var currentVal = $button.attr('value') || $button.text();
					if (currentVal && currentVal.indexOf('{total_price}') !== -1) {
						templateText = currentVal;
					} else {
						templateText = 'Order Now - {total_price}';
					}
				}

				// Inject decoded price into button template
				var newButtonText = templateText.replace('{total_price}', decodedTotal).trim();

				// If button has separate inner text wrapper (e.g. beam/icon buttons), update inner text
				var $innerBtnText = $button.find('.wcsc-btn-text, .wcsc-sticky-text');

				if ($innerBtnText.length) {
					$innerBtnText.html(newButtonText);
				} else {
					$button.html(newButtonText);
				}

				// Update DOM text and attributes synchronously
				$button.attr('value', newButtonText);
				$button.attr('data-value', newButtonText);

				// Also update any standalone .wcsc-btn-price
				$button.find('.wcsc-btn-price').text(decodedTotal);
			});

			this.$container.find('.wcsc-btn-price').text(decodedTotal);
		},

		updateButtonPrice: function (priceText) {
			this.syncOrderButtonPrice(priceText);
		},

		getSelectedBumpProductIds: function () {
			var ids = [];
			this.$container.find('.wcsc-order-bump-checkbox:checked').each(function () {
				var pid = parseInt($(this).data('product-id'), 10);
				if (pid > 0 && ids.indexOf(pid) === -1) {
					ids.push(pid);
				}
			});
			return ids;
		},

		toggleOrderBump: function (productId, actionType) {
			if (!window.wcsc_params || !window.wcsc_params.ajax_url) {
				return;
			}
			var self = this;
			self.showLoading();

			$.ajax({
				url: window.wcsc_params.ajax_url,
				type: 'POST',
				data: {
					action: 'wcsc_toggle_order_bump',
					nonce: window.wcsc_params.nonce,
					product_id: productId,
					action_type: actionType
				},
				dataType: 'json',
				success: function (res) {
					if (res && res.success) {
						if (res.data && res.data.currency_text) {
							self.updateButtonPrice(res.data.currency_text);
						}
						// Refresh native WooCommerce checkout fragments
						$(document.body).trigger('update_checkout');
					} else {
						self.hideLoading();
					}
				},
				error: function (xhr, status, error) {
					console.warn('WCSC Order Bump Error:', error);
					self.hideLoading();
				}
			});
		},

		debouncedSync: function () {
			var self = this;
			if (this.syncTimeout) {
				clearTimeout(this.syncTimeout);
			}
			this.showLoading();
			this.syncTimeout = setTimeout(function () {
				self.syncCart();
			}, 250);
		},

		syncCart: function () {
			if (!window.wcsc_params || !window.wcsc_params.ajax_url) {
				this.hideLoading();
				return;
			}

			var self = this;
			var qty = parseInt(this.$qtyInput.val(), 10) || 1;
			var selectedAttrs = this.getSelectedAttributes();

			var postData = {
				action: 'wcsc_sync_cart',
				nonce: window.wcsc_params.nonce,
				product_id: this.productId,
				variation_id: this.currentVariationId,
				quantity: qty,
				attributes: selectedAttrs,
				bump_product_ids: this.getSelectedBumpProductIds()
			};

			$.ajax({
				url: window.wcsc_params.ajax_url,
				type: 'POST',
				data: postData,
				dataType: 'json',
				success: function (res) {
					if (res && res.success) {
						if (res.data && res.data.currency_text) {
							self.updateButtonPrice(res.data.currency_text);
						}
						// Trigger WooCommerce native checkout update
						$(document.body).trigger('update_checkout');
					} else {
						self.hideLoading();
					}
				},
				error: function (xhr, status, error) {
					console.warn('WCSC Cart Sync Error:', error);
					self.hideLoading();
				}
			});
		},

		initMobileStickyObserver: function () {
			var self = this;
			var stickyBar = self.$container.find('.wcsc-mobile-sticky-bar')[0] || document.getElementById('wcsc-mobile-sticky-bar');
			if (!stickyBar) {
				return;
			}

			// In Elementor editor preview, keep the floating button visible and previewable
			if ($('body').hasClass('elementor-editor-active') || (window.elementorFrontend && window.elementorFrontend.isEditMode && window.elementorFrontend.isEditMode())) {
				$(stickyBar).removeClass('is-hidden');
				return;
			}

			// Track visibility of main checkout wrapper (.wcas-checkout-wrapper)
			var targetWrapper = self.$container.find('.wcas-checkout-wrapper')[0] || document.querySelector('.wcas-checkout-wrapper') || self.$container[0];
			if (!targetWrapper) {
				return;
			}

			var updateVisibility = function () {
				if (window.innerWidth >= 1024) {
					return;
				}
				var rect = targetWrapper.getBoundingClientRect();
				var windowHeight = window.innerHeight || document.documentElement.clientHeight;

				// When .wcas-checkout-wrapper enters the viewport, hide floating button
				if (rect.top < windowHeight && rect.bottom > 0) {
					$(stickyBar).addClass('is-hidden');
				} else if (rect.top >= windowHeight) {
					// User is above checkout form on landing page sections -> display floating button
					$(stickyBar).removeClass('is-hidden');
				} else {
					// User scrolled below checkout section -> keep hidden
					$(stickyBar).addClass('is-hidden');
				}
			};

			if ('IntersectionObserver' in window) {
				var observer = new IntersectionObserver(function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							// Checkout enters viewport -> hide floating button
							$(stickyBar).addClass('is-hidden');
						} else {
							var rect = entry.boundingClientRect;
							// If checkout is below viewport, user is browsing higher content -> show floating button
							if (rect.top > 0) {
								$(stickyBar).removeClass('is-hidden');
							} else {
								// User has scrolled below checkout section -> keep hidden
								$(stickyBar).addClass('is-hidden');
							}
						}
					});
				}, {
					threshold: 0.01,
					rootMargin: '0px 0px 0px 0px'
				});
				observer.observe(targetWrapper);
			}

			// Safety fallback on scroll and resize
			$(window).on('scroll resize orientationchange', function () {
				updateVisibility();
			});

			updateVisibility();
		},

		syncOrderButtonAnimationColor: function () {
			var $btn = this.$container.find('.wcsc-order-now-btn, #place_order');
			if ($btn.length) {
				var el = $btn[0];
				var computedBg = window.getComputedStyle(el).backgroundColor;
				if (computedBg && computedBg !== 'rgba(0, 0, 0, 0)' && computedBg !== 'transparent') {
					el.style.setProperty('--wcsc-order-btn-bg', computedBg);
				}
			}
		},

		updateEditorPreview: function (variation) {
			if (!variation) return;

			var qty = parseInt(this.$qtyInput.val(), 10) || 1;
			var unitPrice = typeof variation.display_price !== 'undefined' ? parseFloat(variation.display_price) : 0;
			var itemSubtotal = unitPrice * qty;

			// Extract currency symbol
			var currencySymbol = '$';
			var $existingAmount = this.$container.find('.woocommerce-Price-currencySymbol');
			if ($existingAmount.length) {
				currencySymbol = $existingAmount.first().text();
			}

			var formatCurrency = function (val) {
				return currencySymbol + (Math.round(val * 100) / 100).toFixed(0);
			};

			// Update preview price in order review table
			var $itemPrice = this.$container.find('.wcsc-preview-item-price');
			if ($itemPrice.length) {
				if (variation.price_html) {
					$itemPrice.html(variation.price_html);
				} else {
					$itemPrice.text(formatCurrency(unitPrice));
				}
			}

			var $previewSubtotal = this.$container.find('.wcsc-preview-subtotal');
			if ($previewSubtotal.length) {
				$previewSubtotal.text(formatCurrency(itemSubtotal));
			}

			// Extract shipping cost in preview
			var shippingCost = 0;
			var $activeShipping = this.$container.find('.wcas-block-shipping li.is-active, .wcas-block-shipping input[type="radio"]:checked');
			if ($activeShipping.length) {
				var $shippingPrice = $activeShipping.closest('li').find('.woocommerce-Price-amount');
				if ($shippingPrice.length) {
					var rawShip = parseFloat($shippingPrice.text().replace(/[^0-9.]/g, ''));
					if (!isNaN(rawShip)) {
						shippingCost = rawShip;
					}
				}
			}

			// Extract order bump totals in preview
			var bumpTotal = 0;
			this.$container.find('.wcsc-order-bump-checkbox:checked').each(function () {
				var $card = $(this).closest('.wcsc-order-bump-card');
				var $bumpPrice = $card.find('.wcsc-order-bump-price .woocommerce-Price-amount').last();
				if ($bumpPrice.length) {
					var rawBump = parseFloat($bumpPrice.text().replace(/[^0-9.]/g, ''));
					if (!isNaN(rawBump)) {
						bumpTotal += rawBump;
					}
				}
			});

			var grandTotal = itemSubtotal + shippingCost + bumpTotal;
			var formattedTotal = formatCurrency(grandTotal);

			var $previewTotal = this.$container.find('.wcsc-preview-total');
			if ($previewTotal.length) {
				$previewTotal.text(formattedTotal);
			}

			// Update button price text
			this.updateButtonPrice(formattedTotal);

			// Update preview item thumbnail (first/main product only)
			var $cartItemImg = this.$container.find('.woocommerce-checkout-review-order-table tbody tr.wcas-order-review-product:first .wcsc-cart-item-image, .woocommerce-checkout-review-order-table tbody tr.cart_item:first .wcsc-cart-item-image');
			if ($cartItemImg.length && variation.image && variation.image.src) {
				$cartItemImg.attr('src', variation.image.src).removeAttr('srcset');
			}
		},

		showValidationModal: function (messages, firstInvalid, customTitle) {
			var self = this;
			var $modal = $('#wcsc-validation-modal, #wcsc-phone-modal');
			if (!$modal.length) {
				$modal = self.$container.find('#wcsc-validation-modal, #wcsc-phone-modal');
			}
			if ($modal.length) {
				var titleText = customTitle || 'প্রয়োজনীয় তথ্য পূরণ করুন';
				$modal.find('.wcsc-phone-modal-title, .wcsc-validation-modal-title').text(titleText);

				var $list = $modal.find('.wcsc-missing-fields-list');
				var $intro = $modal.find('.wcsc-modal-intro-text');
				if ($intro.length) {
					$intro.text('অনুগ্রহ করে নিচের তথ্যগুলো সঠিকভাবে প্রদান করুন:').show();
				}
				if ($list.length) {
					$list.empty();
					if (Array.isArray(messages)) {
						messages.forEach(function (text) {
							$list.append('<li><svg class="wcsc-missing-icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" /></svg> <span>' + text + '</span></li>');
						});
					} else if (typeof messages === 'string') {
						$list.append('<li><svg class="wcsc-missing-icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" /></svg> <span>' + messages + '</span></li>');
					}
				} else {
					var msgText = Array.isArray(messages) ? messages.join('<br>') : messages;
					$modal.find('.wcsc-phone-modal-message, .wcsc-validation-modal-message').html(msgText);
				}
				$modal.data('first-invalid', firstInvalid || null).fadeIn(200);
			} else if (firstInvalid) {
				$('html, body').animate({
					scrollTop: firstInvalid.offset().top - 100
				}, 300);
				firstInvalid.focus();
			}
		}
	};

	/**
	 * =========================================================================
	 * WCSC Modular Widget 1: Product Selector & Grid
	 * =========================================================================
	 */
	function WCSCModularGrid($container) {
		this.$container = $container;
		this.minItems = parseInt($container.data('min-items'), 10) || 1;
		this.maxItems = parseInt($container.data('max-items'), 10) || 0;
		this.scrollTarget = $container.data('scroll-target') || '#wcsc-embedded-checkout';
		this.tiers = [];

		var rawTiers = $container.data('tiers');
		if (rawTiers) {
			try {
				this.tiers = typeof rawTiers === 'string' ? JSON.parse(rawTiers) : rawTiers;
			} catch (e) {
				this.tiers = [];
			}
		}

		this.init();
	}

	WCSCModularGrid.prototype = {
		init: function () {
			var self = this;

			// Card Click Toggle
			this.$container.on('click', '.wcsc-grid-card', function (e) {
				self.toggleCardSelection($(this));
			});

			this.$container.on('click', '.wcsc-card-select-btn', function (e) {
				e.preventDefault();
				e.stopPropagation();
				self.toggleCardSelection($(this).closest('.wcsc-grid-card'));
			});

			// Quantity Stepper
			this.$container.on('click', '.wcsc-qty-plus', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var $card = $(this).closest('.wcsc-grid-card');
				var $val = $card.find('.wcsc-qty-val');
				var current = parseInt($val.val(), 10) || 1;
				$val.val(current + 1);

				if (!$card.hasClass('is-selected')) {
					$card.addClass('is-selected');
				}
				self.updateCalculation();
			});

			this.$container.on('click', '.wcsc-qty-minus', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var $card = $(this).closest('.wcsc-grid-card');
				var $val = $card.find('.wcsc-qty-val');
				var current = parseInt($val.val(), 10) || 1;

				if (current > 1) {
					$val.val(current - 1);
				} else {
					$card.removeClass('is-selected');
				}
				self.updateCalculation();
			});

			this.$container.on('change', '.wcsc-qty-val', function () {
				var val = parseInt($(this).val(), 10) || 1;
				if (val < 1) $(this).val(1);
				self.updateCalculation();
			});

			// Order CTA Button Click (Smooth Scroll + AJAX Sync)
			this.$container.on('click', '.wcsc-grid-cta-btn', function (e) {
				e.preventDefault();
				self.handleCtaClick();
			});

			this.updateCalculation();
		},

		toggleCardSelection: function ($card) {
			$card.toggleClass('is-selected');
			this.updateCalculation();
		},

		getSelectedItems: function () {
			var items = [];
			this.$container.find('.wcsc-grid-card.is-selected').each(function () {
				var $card = $(this);
				var pId = parseInt($card.data('product-id'), 10);
				var qty = parseInt($card.find('.wcsc-qty-val').val(), 10) || 1;
				items.push({
					product_id: pId,
					quantity: qty,
					variation_id: 0,
					attributes: {}
				});
			});
			return items;
		},

		updateCalculation: function () {
			var totalItems = 0;
			var subtotal = 0;
			var selectedProducts = [];

			this.$container.find('.wcsc-grid-card.is-selected').each(function () {
				var $card = $(this);
				var price = parseFloat($card.data('base-price')) || 0;
				var qty = parseInt($card.find('.wcsc-qty-val').val(), 10) || 1;
				totalItems += qty;
				subtotal += (price * qty);

				selectedProducts.push({
					product_id: parseInt($card.data('product-id'), 10),
					is_variable: $card.data('is-variable') == '1',
					quantity: qty,
					price: price
				});
			});

			// Match Tiered Discount
			var discountAmount = 0;
			var discountLabel = '';

			if (this.tiers && this.tiers.length) {
				var sortedTiers = this.tiers.slice().sort(function (a, b) {
					return (parseInt(b.min_qty, 10) || 0) - (parseInt(a.min_qty, 10) || 0);
				});

				for (var i = 0; i < sortedTiers.length; i++) {
					var tier = sortedTiers[i];
					var minQ = parseInt(tier.min_qty, 10) || 0;
					if (totalItems >= minQ) {
						var val = parseFloat(tier.discount_value) || 0;
						if (tier.discount_type === 'percentage') {
							discountAmount = (subtotal * val) / 100;
							discountLabel = tier.tier_label || val + '% OFF';
						} else {
							discountAmount = val;
							discountLabel = tier.tier_label || '$' + val + ' OFF';
						}
						break;
					}
				}
			}

			var finalPrice = Math.max(0, subtotal - discountAmount);

			// Update Summary UI
			this.$container.find('.wcsc-total-items-badge').text(totalItems);

			var $tierBadge = this.$container.find('.wcsc-applied-tier-badge');
			if (discountAmount > 0 && discountLabel) {
				$tierBadge.text(discountLabel).show();
			} else {
				$tierBadge.hide();
			}

			var $strike = this.$container.find('.wcsc-subtotal-strike');
			if (discountAmount > 0) {
				$strike.text('$' + subtotal.toFixed(2)).show();
			} else {
				$strike.hide();
			}

			this.$container.find('.wcsc-calculated-price').text('$' + finalPrice.toFixed(2));

			// Rule warning
			var $warn = this.$container.find('.wcsc-rule-warning');
			var $btn = this.$container.find('.wcsc-grid-cta-btn');

			if (totalItems > 0 && totalItems < this.minItems) {
				$warn.text('Please select at least ' + this.minItems + ' item(s).').show();
				$btn.prop('disabled', true).css('opacity', '0.6');
			} else if (this.maxItems > 0 && totalItems > this.maxItems) {
				$warn.text('Maximum ' + this.maxItems + ' item(s) allowed.').show();
				$btn.prop('disabled', true).css('opacity', '0.6');
			} else {
				$warn.hide();
				$btn.prop('disabled', false).css('opacity', '1');
			}

			// Broadcast event for variation selector or other widgets
			if (selectedProducts.length) {
				$(document).trigger('wcsc_product_selected', [ selectedProducts[0] ]);
			}

			// Auto sync cart if items selected
			if (totalItems > 0 && window.wcsc_params) {
				this.syncCartAjax(false);
			}
		},

		handleCtaClick: function () {
			var self = this;
			var items = this.getSelectedItems();
			if (!items.length) {
				alert('Please select at least one product.');
				return;
			}

			var totalCount = 0;
			items.forEach(function (it) { totalCount += it.quantity; });

			if (totalCount < this.minItems) {
				alert('Please select at least ' + this.minItems + ' item(s).');
				return;
			}

			this.syncCartAjax(true);
		},

		syncCartAjax: function (doScroll) {
			var self = this;
			if (!window.wcsc_params) return;

			var items = this.getSelectedItems();
			var $btn = this.$container.find('.wcsc-grid-cta-btn');
			var $spinner = $btn.find('.wcsc-cta-spinner');

			if (doScroll) {
				$btn.prop('disabled', true);
				$spinner.show();
			}

			$.ajax({
				url: window.wcsc_params.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wcsc_sync_bundle_cart',
					nonce: window.wcsc_params.nonce,
					items: JSON.stringify(items),
					tiers: JSON.stringify(self.tiers)
				},
				success: function (res) {
					if (res.success) {
						// Trigger WooCommerce native checkout update
						$(document.body).trigger('update_checkout');

						if (doScroll && self.scrollTarget && $(self.scrollTarget).length) {
							$('html, body').animate({
								scrollTop: $(self.scrollTarget).offset().top - 40
							}, 600);
						}
					}
				},
				complete: function () {
					if (doScroll) {
						$btn.prop('disabled', false);
						$spinner.hide();
					}
				}
			});
		}
	};

	/**
	 * =========================================================================
	 * WCSC Modular Widget 2: Product Variation Selector
	 * =========================================================================
	 */
	function WCSCVariationSelector($container) {
		this.$container = $container;
		this.productId = parseInt($container.data('product-id'), 10) || 0;
		this.variations = [];

		var raw = $container.data('product-variations');
		if (raw) {
			try {
				this.variations = typeof raw === 'string' ? JSON.parse(raw) : raw;
			} catch (e) {
				this.variations = [];
			}
		}

		this.init();
	}

	WCSCVariationSelector.prototype = {
		init: function () {
			var self = this;

			// Swatch click
			this.$container.on('click', '.wcsc-swatch-item', function (e) {
				e.preventDefault();
				var $btn = $(this);
				var $row = $btn.closest('.wcsc-var-attr-row');
				$row.find('.wcsc-swatch-item').removeClass('is-selected');
				$btn.addClass('is-selected');
				$row.find('.label-selected-val').text($btn.data('value'));
				self.checkMatch();
			});

			// Dropdown change
			this.$container.on('change', '.wcsc-var-dropdown-select', function () {
				self.checkMatch();
			});

			// Listen for product selection from Grid
			$(document).on('wcsc_product_selected', function (e, data) {
				if (data && data.is_variable && data.product_id) {
					self.handleBoundProduct(data.product_id);
				}
			});

			// Auto select first option on load
			this.$container.find('.wcsc-var-attr-row').each(function () {
				var $row = $(this);
				var $firstSwatch = $row.find('.wcsc-swatch-item').first();
				if ($firstSwatch.length) {
					$firstSwatch.addClass('is-selected');
					$row.find('.label-selected-val').text($firstSwatch.data('value'));
				}
			});

			this.checkMatch();
		},

		handleBoundProduct: function (newId) {
			if (this.productId === newId) return;
		},

		checkMatch: function () {
			var selectedAttrs = {};
			var allSelected = true;
			var self = this;

			this.$container.find('.wcsc-var-attr-row').each(function () {
				var $row = $(this);
				var name = $row.data('attribute-name');
				var val = '';

				if ($row.find('.wcsc-swatch-item').length) {
					var $sel = $row.find('.wcsc-swatch-item.is-selected');
					if ($sel.length) val = $sel.data('value');
				} else {
					val = $row.find('.wcsc-var-dropdown-select').val();
				}

				if (!val) allSelected = false;
				selectedAttrs[name] = val;
			});

			if (!allSelected || !this.variations.length) return;

			var matched = null;
			for (var i = 0; i < this.variations.length; i++) {
				var v = this.variations[i];
				var match = true;
				for (var k in v.attributes) {
					var cleanKey = k.replace('attribute_', '');
					if (v.attributes[k] !== '' && selectedAttrs[cleanKey] !== v.attributes[k]) {
						match = false;
						break;
					}
				}
				if (match) {
					matched = v;
					break;
				}
			}

			if (matched) {
				// Update Preview
				if (matched.image && matched.image.thumb_src) {
					self.$container.find('.wcsc-var-preview-img').attr('src', matched.image.thumb_src);
				}
				if (matched.price_html) {
					self.$container.find('.wcsc-var-preview-price').html(matched.price_html);
				}
				if (matched.is_in_stock) {
					self.$container.find('.wcsc-var-stock-status').html('<span style="color:#16a34a;font-size:12px;font-weight:600;">✓ In Stock</span>');
				} else {
					self.$container.find('.wcsc-var-stock-status').html('<span style="color:#dc2626;font-size:12px;font-weight:600;">✗ Out of Stock</span>');
				}

				// Sync with cart via AJAX
				if (window.wcsc_params) {
					$.ajax({
						url: window.wcsc_params.ajax_url,
						type: 'POST',
						dataType: 'json',
						data: {
							action: 'wcsc_sync_cart',
							nonce: window.wcsc_params.nonce,
							product_id: self.productId,
							variation_id: matched.variation_id,
							quantity: 1,
							attributes: selectedAttrs
						},
						success: function () {
							$(document.body).trigger('update_checkout');
						}
					});
				}
			}
		}
	};

	/**
	 * Elementor & Document Initialization Hook
	 */
	function initWidgets($scope) {
		// All-in-one product checkout widgets
		var $elements = $scope ? $scope.find('.wcsc-product-checkout-widget') : $('.wcsc-product-checkout-widget');
		$elements.each(function () {
			var $this = $(this);
			if (!$this.data('wcsc_initialized')) {
				$this.data('wcsc_initialized', true);
				new WCSCWidget($this);
			}
		});

		// Modular Widget 1: Product Grid
		var $grids = $scope ? $scope.find('.wcsc-product-grid-container') : $('.wcsc-product-grid-container');
		$grids.each(function () {
			var $this = $(this);
			if (!$this.data('wcsc_grid_init')) {
				$this.data('wcsc_grid_init', true);
				new WCSCModularGrid($this);
			}
		});

		// Modular Widget 2: Variation Selector
		var $vars = $scope ? $scope.find('.wcsc-variation-selector-widget') : $('.wcsc-variation-selector-widget');
		$vars.each(function () {
			var $this = $(this);
			if (!$this.data('wcsc_var_init')) {
				$this.data('wcsc_var_init', true);
				new WCSCVariationSelector($this);
			}
		});
	}

	$(document).ready(function () {
		initWidgets();
	});

	// Hook into Elementor Frontend
	$(window).on('elementor/frontend/init', function () {
		if (window.elementorFrontend && window.elementorFrontend.hooks) {
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/wcsc_product_checkout.default',
				function ($scope) {
					initWidgets($scope);
				}
			);
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/wcsc_product_grid.default',
				function ($scope) {
					initWidgets($scope);
				}
			);
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/wcsc_variation_selector.default',
				function ($scope) {
					initWidgets($scope);
				}
			);
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/wcsc_embedded_checkout.default',
				function ($scope) {
					initWidgets($scope);
				}
			);
		}
	});

})(jQuery);
