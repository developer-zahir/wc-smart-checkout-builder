<?php
/**
 * Plugin Name:       WC Smart Checkout Builder
 * Plugin URI:        https://github.com/developer-zahir/wc-smart-checkout-builder
 * Description:       A lightweight Elementor widget for selecting WooCommerce products and checking out.
 * Version:           1.9.28
 * Author:            Developer Zahir
 * Author URI:        https://developerzahir.com
 * Text Domain:       wc-smart-checkout-builder
 * Domain Path:       /languages
 * GitHub Plugin URI: https://github.com/developer-zahir/wc-smart-checkout-builder
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 5.0
 * Elementor tested up to: 3.25
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'WCSC_VERSION', '1.9.28' );
define( 'WCSC_FILE', __FILE__ );
define( 'WCSC_PATH', plugin_dir_path( __FILE__ ) );
define( 'WCSC_URL', plugin_dir_url( __FILE__ ) );
define( 'WCSC_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Check dependencies and initialize the plugin.
 */
function wcsc_cleanup_legacy_subplugin() {
	$legacy_dir = WCSC_PATH . 'wooflexibundle-builder';
	if ( is_dir( $legacy_dir ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		\WP_Filesystem();
		global $wp_filesystem;
		if ( $wp_filesystem ) {
			$wp_filesystem->delete( $legacy_dir, true );
		} else {
			$delete_recursive = function( $dir ) use ( &$delete_recursive ) {
				if ( ! is_dir( $dir ) ) return;
				$items = scandir( $dir );
				if ( is_array( $items ) ) {
					foreach ( $items as $item ) {
						if ( '.' === $item || '..' === $item ) continue;
						$path = $dir . DIRECTORY_SEPARATOR . $item;
						is_dir( $path ) ? $delete_recursive( $path ) : @unlink( $path );
					}
				}
				@rmdir( $dir );
			};
			$delete_recursive( $legacy_dir );
		}
	}
	$active_plugins = get_option( 'active_plugins', array() );
	$cleaned = false;
	if ( is_array( $active_plugins ) ) {
		foreach ( $active_plugins as $key => $plugin_path ) {
			if ( false !== strpos( $plugin_path, 'wooflexibundle' ) ) {
				unset( $active_plugins[ $key ] );
				$cleaned = true;
			}
		}
		if ( $cleaned ) {
			update_option( 'active_plugins', array_values( $active_plugins ) );
		}
	}
	$installed_ver = get_option( 'wcsc_version' );
	if ( $installed_ver !== WCSC_VERSION ) {
		delete_site_transient( 'wcsc_github_release_data' );
		delete_site_transient( 'update_plugins' );
		update_option( 'wcsc_flush_rewrite_rules', 'yes' );
		update_option( 'wcsc_version', WCSC_VERSION );
	}
}

/**
 * Plugin activation hook: schedule rewrite rules flush.
 */
function wcsc_activate() {
	update_option( 'wcsc_flush_rewrite_rules', 'yes' );
}
register_activation_hook( WCSC_FILE, 'wcsc_activate' );

function wcsc_init() {
	wcsc_cleanup_legacy_subplugin();
	// Check if WooCommerce is active.
	$woocommerce_active = class_exists( 'WooCommerce' ) || in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ), true );

	// Check if Elementor is active.
	$elementor_active = did_action( 'elementor/loaded' ) || in_array( 'elementor/elementor.php', apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ), true );

	// Include and initialize GitHub automatic updater early.
	require_once WCSC_PATH . 'includes/class-updater.php';
	new \WCSC\Updater( WCSC_BASENAME, WCSC_VERSION );

	if ( ! $woocommerce_active || ! $elementor_active ) {
		add_action( 'admin_notices', 'wcsc_missing_dependencies_notice' );
		return;
	}

	// Autoload / include plugin core classes.
	require_once WCSC_PATH . 'includes/class-product-handler.php';
	require_once WCSC_PATH . 'includes/class-variation-handler.php';
	require_once WCSC_PATH . 'includes/class-checkout-handler.php';
	require_once WCSC_PATH . 'includes/class-license-manager.php';
	require_once WCSC_PATH . 'includes/class-plugin.php';

	// Initialize License Manager.
	\WCSC\License_Manager::init();

	// Bootstrap plugin.
	\WCSC\Plugin::instance();
}
add_action( 'plugins_loaded', 'wcsc_init', 20 );

/**
 * Admin notice for missing required plugins.
 */
function wcsc_missing_dependencies_notice() {
	$missing = array();

	if ( ! class_exists( 'WooCommerce' ) ) {
		$missing[] = '<strong>WooCommerce</strong>';
	}
	if ( ! did_action( 'elementor/loaded' ) ) {
		$missing[] = '<strong>Elementor</strong>';
	}

	if ( ! empty( $missing ) ) {
		$message = sprintf(
			/* translators: %s: Comma-separated list of missing plugins */
			__( 'The %1$s plugin requires %2$s to be installed and active.', 'wc-smart-checkout-builder' ),
			'<strong>WooCommerce Product Variation & Checkout Elementor Widget</strong>',
			implode( ' and ', $missing )
		);
		printf( '<div class="notice notice-error"><p>%s</p></div>', wp_kses_post( $message ) );
	}
}

/**
 * Load plugin textdomain.
 */
function wcsc_load_textdomain() {
	load_plugin_textdomain( 'wc-smart-checkout-builder', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'wcsc_load_textdomain' );
